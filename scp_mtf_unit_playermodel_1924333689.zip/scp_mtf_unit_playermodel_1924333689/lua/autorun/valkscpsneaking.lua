list.Set( "PlayerOptionsModel", "SCPMTF", "models/valk/MGSV/MSF/SneakingSuit/c_arms.mdl" )
player_manager.AddValidModel( "SCPMTF", "models/valk/MGSV/MSF/SneakingSuit/SneakingSuit_Male.mdl" )
player_manager.AddValidHands( "SCPMTF", "models/valk/MGSV/MSF/SneakingSuit/c_arms.mdl", 1, "00000000" )



